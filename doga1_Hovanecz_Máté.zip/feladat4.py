import math
def fel4():
    valSzam = float(input("Kérem adjon meg egy valós számot:"))

    valSzam = valSzam.__floor__()

    print(f"Kerekített értéke: {valSzam}")

    print("\n")