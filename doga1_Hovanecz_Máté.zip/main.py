import feladat1
import feladat2
import feladat3
import feladat4
import feladat5

feladat1.fel1()
feladat2.fel2()
feladat3.fel3()
feladat4.fel4()
feladat5.fel5()

